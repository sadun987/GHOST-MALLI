# Proguard rules
-keepattributes *Annotation*
